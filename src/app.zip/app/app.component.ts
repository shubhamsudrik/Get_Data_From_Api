
import { Component, OnInit } from '@angular/core';
import { CoreBase, IMIRequest, IMIResponse, IUserContext, MIRecord } from '@infor-up/m3-odin';
import { MIService, UserService } from '@infor-up/m3-odin-angular';
import { map } from 'jquery';
// import Swal from 'sweetalert2/dist/sweetalert2.js'


/* Below is the new task.
Take input from user for customer order number (ORNO)
Use the ORNO and CONO as input for OIS100MI LstLine transaction
Input CONO and ORNO
Output PONR POSX ITNO ORQT and NLAM
*/


@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
})

export class AppComponent extends CoreBase implements OnInit {
      userContext = {} as IUserContext;
      isBusy = false;
      company: string;
   
      supplierNo :string;
      puNo:string;
      errormsg :string;
      lineNo:string='';
      lineSuffix:string='';
      ItemNumber :string='';
      itemNo:string='';
      itemDescription:string='';
      orderQuantity:string='';
      netAmount:string='';
      name:string='';

      orNo : string;
      poNr : string;
      poSx : string;
      itNo : string;
      orQt : string;
      nlAm : string;
      cuNm : string;
      itDs : string;
      lineitems : MIRecord[];
      litems : MIRecord[];

   constructor(private miService: MIService, private userService: UserService) {
      super('AppComponent');
   }

   ngOnInit() {
      
   }


   onClickLoad(): void {
     // console.log(this.puNo);
     console.log(this.itNo);

      console.log(this.orNo);

      if(this.company!==null){}
      this.logInfo('onClickLoad');
      
      this.setBusy(true);
      this.userService.getUserContext().subscribe((userContext: IUserContext) => {
         this.setBusy(false);
         this.logInfo('onClickLoad: Received user context');
         this.userContext = userContext;
         this.updateUserValues(userContext);
         this.callAllFunction();
      }, (error) => {
         this.setBusy(false);
         this.logError('Unable to get userContext ' + error);
      });
   }

   updateUserValues(userContext: IUserContext) {
      this.company = userContext.company;
     
   }

   private setBusy(isBusy: boolean) {
      this.isBusy = isBusy;
   }
   
   async callAllFunction() {
      
        this.OIS100MI_LstLine(this.company,this.orNo);
        this.MMS200MI_GetItmBasic(this.company,this.itNo);
      }

     MMS200MI_GetItmBasic(company: string, itemnumber: string) {
   const inputRecord = new MIRecord();
   inputRecord.setNumber("CONO", company);
   inputRecord.setNumber("ITNO", itemnumber);

   const request: IMIRequest = {
      program: "MMS200MI",
      transaction: "GetItmBasic",
      record: inputRecord,
      outputFields: ["ITNO", "ITDS"]
   };

   this.setBusy(true);
   this.miService.execute(request).subscribe((response: IMIResponse) => {
      this.setBusy(false);
      if (!response.hasError()) {
         const records: MIRecord[] = response.items as MIRecord[];
         this.lineitems.forEach((record: MIRecord) => {
            const itemNumber = record["ITNO"];
            const matchingRecord = records.find((r: MIRecord) => r["ITNO"] === itemNumber);
            if (matchingRecord) {
               record["ITDS"] = matchingRecord["ITDS"];
            }
         });
      }
   }, (response) => {
      // Handle error response
   });
}

      


//       MMS200MI_GetItmBasic(company: string,itemnumber: string){
//          const inputRecord = new MIRecord();

//          const companyName =company;
//          inputRecord.setNumber("CONO", companyName);

//          const iDescription = itemnumber;
//          inputRecord.setNumber("ITNO", iDescription);

//       const request: IMIRequest ={
//          program: "MMS200MI",
//          transaction: "GetItmBasic",
//          record: inputRecord,
//          outputFields: ["ITDS"]
//          };
//          console.log(this.itDs)
         
//          this.setBusy(true);
//       this.miService.execute(request).subscribe((response: IMIResponse) => {
//          this.setBusy(false);
         
// console.log(response)


//          if (!response.hasError()) {
//             const records: MIRecord[] = response.items as MIRecord[];
//             records.forEach((record: MIRecord) => {
//                const itemDescription = record["ITDS"];
//                // Do something with the item description
//             });
//          }
   //    }, (response) => {
   //       // Handle error response
   //    });
   // }
      //    if (!response.hasError()) {
      //    //   const records:MIRecord[] 
      //     this.lineitems = response.items as MIRecord [];
         


   

      //       this.itemDescription = this.itDs;
      // console.log(response.items);
      //    }
        
      //    if (response.hasError) {

      //    }
      // }, (response) => {
      //   //this error code is use to show erroe in purchase order
      //    if(response.errorCode=='WPU0803'){
      //       this.errormsg="Entered purchase order number is incorrect";
      //    }else{
      //       this.errormsg=response.errorMessage
      //    }
      //    console.log(response);
      //    this.setBusy(false);
      // });
      // };
   
   
 
   
    OIS100MI_LstLine(company: string, CustomerOrderNumber: string) {
      const inputRecord = new MIRecord();
 
            const companyName = company;
            inputRecord.setNumber("CONO", companyName);

            const cOrderNumber = CustomerOrderNumber;
            inputRecord.setNumber("ORNO",cOrderNumber);


      const request: IMIRequest = {
         program: "OIS100MI",
         transaction: "LstLine",
         record: inputRecord,
         outputFields: ["PONR","POSX", "ITNO","ORQT","NLAM"]
      };

console.log(this.poNr)
      this.setBusy(true);
      this.miService.execute(request).subscribe((response: IMIResponse) => {
         console.log(response);
         this.setBusy(false);


         if (!response.hasError()) {
            // const records: MIRecord []
           this.lineitems = response.items as MIRecord [];
             console.log(this.lineitems)

         // //   console.log(this.lineitems)
         // //    this.lineitems.forEach((record : MIRecord) => {
         // //    this.poNr = record["PONR"];
         // //    this.poSx = record["POSX"];
         // //    this.itNo = record["ITNO"];
         // //    this.orQt = record["ORQT"];
         // //    this.nlAm = record["NLAM"]; 

            
         // //  });
           
         //    console.log("success: PONR:",this.poNr)
         
         //    // this.lineNo = this.poNr;
         //    // this.lineSuffix = this.poSx;
         //    // this.itemNo = this.itNo;
            
         //    // this.orderQuantity= this.orQt;
         //    // this.netAmount= this.nlAm;
         //    //this.name= "Name :" + this.cuNm;
         // }
        
         if (response.hasError) {

         }
      }
   }, (response) => {
      //  this error code is use to show erroe in purchase order
         if(response.errorCode=='WPU0803'){
            this.errormsg="Entered purchase order number is incorrect";
         }else{
            this.errormsg=response.errorMessage
         }
         console.log(response);
         this.setBusy(false);
      });

     
  }

}
